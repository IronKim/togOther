import React from 'react';
import Form from '../components/community/planner/Form';

const Planner = () => {
    return (
        <div>
            <Form/>
        </div>
    );
};

export default Planner;