import Main from './components/Main';
import './css/default.css';

function App() {
  return (
    <div>
      <Main />
    </div>
  );
}

export default App;