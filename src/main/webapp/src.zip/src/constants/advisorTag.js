export const advisorTag = {
    USER: '유저 관리',
    CITY: '도시 관리',
    PLACE: '장소 관리',
}