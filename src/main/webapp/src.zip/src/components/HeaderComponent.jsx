import React from 'react';

const HeaderComponent = () => {
    return (
        <div>
            
        </div>
    );
};

export default HeaderComponent;