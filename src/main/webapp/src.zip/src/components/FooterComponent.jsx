import React from 'react';

const FooterComponent = () => {
    return (
        <div>
            
        </div>
    );
};

export default FooterComponent;